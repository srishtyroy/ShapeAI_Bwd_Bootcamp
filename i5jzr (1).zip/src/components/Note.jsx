import React from "react";

function Note() {
  return (
    <div classname="note">
      <h1>Javascript and React.js</h1>
      <p>This was an amazing bootcamp taken up by Shaurya Sinha.We covered everything from Scratch including Javascript and React.js, HTML.
      </p>
    </div>
  );
}

export default Note;